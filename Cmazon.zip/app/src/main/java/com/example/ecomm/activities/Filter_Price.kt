package com.example.ecomm.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ecomm.R

class Filter_Price : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter__price)
        supportActionBar?.hide()
    }
}