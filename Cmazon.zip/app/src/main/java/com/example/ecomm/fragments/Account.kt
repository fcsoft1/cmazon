package com.example.ecomm.fragments
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.ecomm.R
import com.example.ecomm.activities.*
import kotlinx.android.synthetic.main.activity_account.*

class Account:Fragment(R.layout.activity_account) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        lin_editprofile.setOnClickListener(View.OnClickListener {
            val intent = Intent(context,EditProfile::class.java)
            startActivity(intent)
        } )

        lin_orders.setOnClickListener( View.OnClickListener {
            val intent = Intent(context,MyOrders::class.java)
            startActivity(intent)
        })

        lin_settings.setOnClickListener( View.OnClickListener {
            val intent = Intent(context,Settings::class.java)
            startActivity(intent)
        })

        lin_addressbook.setOnClickListener( View.OnClickListener {
            val intent = Intent(context,MyAddresses::class.java)
            startActivity(intent)
        })

        lin_notification.setOnClickListener( View.OnClickListener {
            val intent = Intent(context,Notification::class.java)
            startActivity(intent)
        })

        txt_logout.setOnClickListener( View.OnClickListener {
            val sp: SharedPreferences? =
                context?.getSharedPreferences("app", Context.MODE_PRIVATE)
            val spEdit = sp?.edit()
            spEdit?.putString("fullname","")
            spEdit?.putString("country", "")
            spEdit?.putString("email", "")
            spEdit?.putString("id", "")
            spEdit?.putString("mobile", "")
            spEdit?.putString("profile_image", "")
            spEdit?.putString("referral_code", "")
            spEdit?.putString("referred_users", "")
            spEdit?.putString("vAuthToken", "")
            spEdit?.putString("status", "")
            spEdit?.commit()
            val intent = Intent(activity,Login::class.java)
            activity?.finish()
            startActivity(intent)
        })

    }
}