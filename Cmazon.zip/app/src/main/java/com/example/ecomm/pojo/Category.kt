package com.example.ecomm.pojo

class Category(id: String?,title: String?, image: String?) {
   private var id: String= ""
   private var title: String= ""
   private var image: String= ""
   init {
      this.title = title!!
      this.image = image!!
      this.id    = id!!
   }
   fun getTitle(): String? {
      return title
   }
   fun setTitle(name: String?) {
      title = name!!
   }

   fun getImage(): String? {
      return image
   }
   fun setImage(genre: String?) {
      this.image = genre!!
   }

   fun getId(): String{
      return id;
   }
   fun setId(id: String){
      this.id=id
   }
}