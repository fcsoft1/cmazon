package com.example.ecomm.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ecomm.R
import com.example.ecomm.activities.Coupan
import com.example.ecomm.activities.Product_Details
import com.example.ecomm.activities.SearchResult
import com.example.ecomm.pojo.Brands
import com.example.ecomm.pojo.Category
import com.example.ecomm.pojo.Coupon
import com.example.ecomm.pojo.Notification

class AdapterCoupon(private val dataSet: ArrayList<Coupon>, private val context: Activity?,private val hide_apply: Boolean) :
        RecyclerView.Adapter<AdapterCoupon.ViewHolder>() {

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var btn_apply = view.findViewById<Button>(R.id.btn_apply)
        var txt_title = view.findViewById<TextView>(R.id.txt_title)
        var txt_expdate = view.findViewById<TextView>(R.id.txt_expdate)
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        val view = LayoutInflater.from(context)
                .inflate(R.layout.adapter_coupan, viewGroup, false)

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val obj=dataSet[position];
        viewHolder?.txt_title?.text = obj.getTitle()
        viewHolder?.txt_expdate?.text = obj.getExp_date()

        if(!hide_apply){
            viewHolder?.btn_apply.visibility=View.GONE
        }
        viewHolder?.btn_apply.setOnClickListener(View.OnClickListener {
//            val intent = Intent(context, SearchResult::class.java)
//            context?.startActivity(intent)
            context?.finish()
        })
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = dataSet.size

}
