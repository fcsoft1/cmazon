package com.example.ecomm.api.get_brands

import com.example.ecomm.pojo.Chat

class GetBrandResponse(val status: Boolean, val message:String, val data: GetBrandData)
