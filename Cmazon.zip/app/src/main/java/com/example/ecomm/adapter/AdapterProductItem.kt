package com.example.ecomm.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ecomm.R
import com.example.ecomm.activities.Product_Details
import com.example.ecomm.pojo.Trending
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_home.*

class AdapterProductItem(private val dataSet: ArrayList<Trending>, private val design:Int, private val context: Context?) :
        RecyclerView.Adapter<AdapterProductItem.ViewHolder>() {

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
//        val txt_company: TextView
//        val txt_price: TextView
//        val txt_label: TextView
//        val txt_discount_label: TextView
//        val txt_rating: TextView
//        val txt_description: TextView
//        val img_product_photo: ImageView

//        init {
            // Define click listener for the ViewHolder's View.
            val img_product_photo = view.findViewById<ImageView>(R.id.img_product_photo)
            val txt_company = view.findViewById<TextView>(R.id.txt_company)
            val txt_price = view.findViewById<TextView>(R.id.txt_price)
            val txt_label = view.findViewById<TextView>(R.id.txt_label)
            val txt_discount_label = view.findViewById<TextView>(R.id.txt_discount_label)
            val txt_rating = view.findViewById<TextView>(R.id.txt_rating)
            val txt_description = view.findViewById<TextView>(R.id.txt_description)
            val lin_mainview = view.findViewById<LinearLayout>(R.id.lin_mainview)
//        }
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        var view : View = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.adatper_tranding, viewGroup, false);
        if(design==0) {
            view = LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.adatper_tranding, viewGroup, false)

        }
        if(design==1) {
            view = LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.adapter_all_products, viewGroup, false)

        }
        if(design==2) {
            view = LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.adatper_tranding_full_width, viewGroup, false)

        }
        if(design==4) {
            view = LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.adapter_recommanded, viewGroup, false)

        }

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val obj=dataSet[position];
        viewHolder?.txt_company?.text = obj.getcompany()
        viewHolder?.txt_discount_label?.text = obj.getdiscount()
        viewHolder?.txt_label?.text = obj.getlabel()
        viewHolder?.txt_price?.text = obj.getprice()
        viewHolder?.txt_rating?.text = obj.getrating()
        viewHolder?.txt_description?.text = obj.getdescription()

        Picasso.with(context).
        load(obj.getproduct_photo()).
        into(viewHolder.img_product_photo)

        viewHolder?.lin_mainview.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, Product_Details::class.java)
            intent.putExtra("product_id",obj.getid())
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context?.startActivity(intent)
        })
        viewHolder?.img_product_photo.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, Product_Details::class.java)
            intent.putExtra("product_id",obj.getid())
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context?.startActivity(intent)
        })
//        viewHolder.img_product_photo.set = obj.getTitle()
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = dataSet.size

}
