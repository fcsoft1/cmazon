package com.example.ecomm.activities

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import com.example.ecomm.R
import kotlinx.android.synthetic.main.activity_o_t_p.*

class OTP : AppCompatActivity() {
    var change_button:String=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_o_t_p)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()
        if(intent.getBooleanExtra("fromforgotpass",false)){
            change_button="Change"
        }
        txt_otp_number.setText(intent.extras?.get("mobile").toString()+"      "+change_button)

        txt_otp_number.setOnClickListener(View.OnClickListener {
            if(change_button.equals("Change")) {
                val intent = Intent(applicationContext, ForgotPassword::class.java)
                finish()
                startActivity(intent)
            }
        })
        btn_continue.setOnClickListener(View.OnClickListener {
            val otp= edt_refral.otp
            var isValid : Boolean = true;
            if(otp?.isEmpty()!!){
                isValid=false
                showDialog("Validation","OTP Empty not allowd",this)
                return@OnClickListener
            }
            if(isValid) {
                if(intent.getBooleanExtra("fromforgotpass",false)) {
                    val intent = Intent(applicationContext, ResetPassword::class.java)
                    finish()
                    startActivity(intent)
                }else {
                    val intent = Intent(applicationContext,AddAddress::class.java)
                    intent.putExtra("from_signup",true)
                    intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                    finish()
                }
            }
        })
    }
    fun showDialog(title: String,dialogMessage: String, context: Context) {
        val builder = AlertDialog.Builder(context)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(dialogMessage)
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        //performing positive action
        builder.setPositiveButton("Ok"){dialogInterface, which ->

        }

        // Create the AlertDialog
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()

    }

    override fun onBackPressed() {
        if(change_button.equals("Change")) {
            val intent = Intent(applicationContext, ForgotPassword::class.java)
            finish()
            startActivity(intent)
        }else{
            finish()
        }
    }
}