package com.example.ecomm.api.remove_address

import com.example.ecomm.pojo.Chat

class RemoveAddressResponse(val status: Boolean, val message:String, val data: RemoveAddressData)
