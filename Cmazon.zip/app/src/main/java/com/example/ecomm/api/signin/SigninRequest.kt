package com.example.ecomm.api.signin

import com.google.gson.annotations.SerializedName

class SigninRequest(@SerializedName("email") var email: String,
                    @SerializedName("password") var password: String)