package com.example.ecomm.api.change_notification

import com.google.gson.annotations.SerializedName

class ChangeNotificationRequest(@SerializedName("status") var status: String)