package com.example.ecomm.api.add_address

import com.google.gson.annotations.SerializedName

class AddAddressRequest(@SerializedName("option") var option: String,
                        @SerializedName("type") var type: String,
                        @SerializedName("address") var address: String,
                        @SerializedName("home") var home: String,
                        @SerializedName("area") var area: String,
                        @SerializedName("city") var city: String)
