package com.example.ecomm.activities

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.ecomm.R
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.signup.SignUpData
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_signup.*
import kotlinx.android.synthetic.main.activity_signup.btn_continue
import kotlinx.android.synthetic.main.activity_signup.edt_email
import kotlinx.android.synthetic.main.activity_signup.edt_pass
import kotlinx.android.synthetic.main.activity_signup.img_show_hide_pass
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Signup : AppCompatActivity() {
    var password_show : Boolean = false;
    var password_show1 : Boolean = false;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()
        btn_continue.setOnClickListener( View.OnClickListener {
            var isValid : Boolean = true;

            if(edt_name.text.isEmpty()){
                isValid=false
                showDialog("Validation","Name Empty not allowd",this)
                return@OnClickListener
            }

            if(edt_email.text.isEmpty()){
                isValid=false
                showDialog("Validation","Email Empty not allowd",this)
                return@OnClickListener
            }

            if(edt_pass.text.isEmpty()){
                isValid=false
                showDialog("Validation","Password Empty not allowd",this)
                return@OnClickListener
            }

            if(edt_pass.text.length<9){
                isValid=false
                showDialog("Validation","Password length should be minimum 9 char.",this)
                return@OnClickListener
            }
            if(edt_pass1.text.isEmpty()){
                isValid=false
                showDialog("Validation","Re-Password Empty not allowd",this)
                return@OnClickListener
            }

            if(!edt_pass.text.toString().equals(edt_pass1.text.toString())){
                isValid=false
                showDialog("Validation","Password and Re-Password are not same",this)
                return@OnClickListener
            }

            if(edt_phone.text.isEmpty()){
                isValid=false
                showDialog("Validation","Please enter your phone number",this)
                return@OnClickListener
            }

//            if(edt_refral.text.isEmpty()){
//                isValid=false
//                showDialog("Validation","Referal Empty not allowd",this)
//                return@OnClickListener
//            }

            if(isValid) {
                Signup_Now()
            }
        } )
        lin_login.setOnClickListener( View.OnClickListener {
            val intent = Intent(applicationContext,Login::class.java)
            finish()
            startActivity(intent)
            this.overridePendingTransition( R.anim.slide_in_up, R.anim.slide_out_up );
        } )
        img_back.setOnClickListener( View.OnClickListener {
            val intent = Intent(applicationContext,Login::class.java)
            finish()
            startActivity(intent)
            this.overridePendingTransition( R.anim.slide_in_up, R.anim.slide_out_up );
        } )
        img_show_hide_pass.setOnClickListener(View.OnClickListener {
            if(password_show){
                password_show=false
                edt_pass.inputType = InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD;
                edt_pass.transformationMethod= PasswordTransformationMethod.getInstance()
                img_show_hide_pass.setImageResource(R.drawable.show_pass)
            }else{
                password_show=true
                edt_pass.inputType = InputType.TYPE_CLASS_TEXT;
                edt_pass.transformationMethod=null
                img_show_hide_pass.setImageResource(R.drawable.hide_pass)
            }
        })
        img_show_hide_pass1.setOnClickListener(View.OnClickListener {
            if(password_show1){
                password_show1=false
                edt_pass1.inputType = InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD;
                edt_pass1.transformationMethod= PasswordTransformationMethod.getInstance()
                img_show_hide_pass1.setImageResource(R.drawable.show_pass)
            }else{
                password_show1=true
                edt_pass1.inputType = InputType.TYPE_CLASS_TEXT;
                edt_pass1.transformationMethod=null
                img_show_hide_pass1.setImageResource(R.drawable.hide_pass)
            }
        })

    }

    fun showDialog(title: String,dialogMessage: String, context: Context) {
        val builder = AlertDialog.Builder(context)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(dialogMessage)
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        //performing positive action
        builder.setPositiveButton("Ok"){dialogInterface, which ->

        }

        // Create the AlertDialog
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()

    }
    private fun Signup_Now() {
        val progressDialog = ProgressDialog(this@Signup)
        progressDialog.setTitle(getString(R.string.app_name))
        progressDialog.setMessage("Please wait...")
        progressDialog.show()
        ApiService.ApiCall().doRegister(edt_name.text.toString(),
                edt_email.text.toString(),
                edt_pass.text.toString(),
                edt_pass1.text.toString(),
                "IN",
                edt_phone.text.toString(),
                edt_refral.text.toString()
        ).enqueue(object : Callback<SignUpData> {
            override fun onResponse(
                call: Call<SignUpData>,
                response: Response<SignUpData>
            ) {
                progressDialog.dismiss()
//                Log.d("Response::::", response.body().toString())
                if (response.body()?.status==200){
                    Toast.makeText(applicationContext,response.body()!!.message+"",Toast.LENGTH_SHORT).show()
                    val intent = Intent(applicationContext, OTP::class.java)
                    intent.putExtra("fromforgotpass",false)
                    intent.putExtra("mobile",edt_phone.text)
                    finish()
                    startActivity(intent)
                }else{
                    Toast.makeText(applicationContext, response.message(), Toast.LENGTH_LONG).show()
                    val intent = Intent(applicationContext, OTP::class.java)
                    intent.putExtra("fromforgotpass",false)
                    intent.putExtra("mobile",edt_phone.text)
                    finish()
                    startActivity(intent)
                }
            }

            override fun onFailure(call: Call<SignUpData>, t: Throwable) {
                progressDialog.dismiss()
            }

        })
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        val intent = Intent(applicationContext,Login::class.java)
        finish()
        startActivity(intent)
    }
}