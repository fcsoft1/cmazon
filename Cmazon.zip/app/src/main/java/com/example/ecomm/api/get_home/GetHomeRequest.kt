package com.example.ecomm.api.get_home

import com.google.gson.annotations.SerializedName

class GetHomeRequest()