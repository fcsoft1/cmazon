package com.example.ecomm.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecomm.R
import com.example.ecomm.adapter.AdapterMyOrder
import com.example.ecomm.adapter.AdapterProductItem
import com.example.ecomm.pojo.MyOrderItem
import com.example.ecomm.pojo.MyOrderView
import com.example.ecomm.pojo.Trending
import kotlinx.android.synthetic.main.fragment_orders.*

class MyOrderListCancel:Fragment(R.layout.fragment_orders) {
    private val ar_myorder = ArrayList<MyOrderView>()
    private lateinit var myOrderAdapter: AdapterMyOrder
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // All Products
        var ar_order_item=MyOrderItem("1", "Revenador",
            "Named after a Filipino God of Thunder....","500 CFA",
            "Hand-patinated leather","Upto 20% Discount","3.6",
            "http://www.google.com")

        var ar_order_item1=MyOrderItem("1", "Revenador",
            "Named after a Filipino God of Thunder....","500 CFA",
            "Hand-patinated leather","Upto 20% Discount","3.6",
            "http://www.google.com")

        val ar_myorder_item = ArrayList<MyOrderItem>()
        ar_myorder_item.add(ar_order_item)
        ar_myorder_item.add(ar_order_item1)
        var objy = MyOrderView("#1254887754",
            "12 Jul 2021",
            "Arrived",
            "1",
            ar_myorder_item,"3")
        ar_myorder.add(objy)


        myOrderAdapter = AdapterMyOrder(ar_myorder,2,context)
        val layoutManager2 = LinearLayoutManager(context)
        rec_myorders.layoutManager = layoutManager2
        rec_myorders.itemAnimator = DefaultItemAnimator()
        rec_myorders.adapter = myOrderAdapter
    }
}