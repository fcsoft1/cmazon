package com.example.ecomm.api.change_notification

import com.example.ecomm.pojo.Chat

class ChangeNotificationResponse(val status: Boolean, val message:String,val data: ArrayList<ChangeNotificationData>)
