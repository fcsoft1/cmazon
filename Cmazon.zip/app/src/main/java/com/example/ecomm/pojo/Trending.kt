package com.example.ecomm.pojo

class Trending(id: String?, company: String?, description: String?
               , price: String?, label: String?, discount: String?
               , rating: String?
               , product_photo: String?) {
      private  var id: String = ""
      private  var company: String= ""
      private  var description: String= ""
      private  var price: String= ""
      private  var label: String= ""
      private  var discount: String= ""
      private  var rating: String= ""
      private  var product_photo: String= ""
   init {
      this.id=id!!
      this.company= company!!
      this.price= price!!
      this.label= label!!
      this.discount= discount!!
      this.rating= rating!!
      this.product_photo= product_photo!!
      this.description= description!!
   }
   fun getid(): String? {
      return id
   }
   fun setid(id: String?) {
      this.id = id!!
   }
   fun getcompany(): String? {
      return company
   }
   fun setcompany(company: String?) {
      this.company = company!!
   }
   fun getprice(): String? {
      return price
   }
   fun setprice(price: String?) {
      this.price = price!!
   }
   fun getlabel(): String? {
      return label
   }
   fun setlabel(label: String?) {
      this.label = label!!
   }
   fun getdiscount(): String? {
      return discount
   }
   fun setdiscount(discount_label: String?) {
      this.discount = discount_label!!
   }
   fun getrating(): String? {
      return rating
   }
   fun setrating(rating: String?) {
      this.rating = rating!!
   }
   fun getproduct_photo(): String? {
      return product_photo
   }
   fun setproduct_photo(product_photo: String?) {
      this.product_photo = product_photo!!
   }
   fun getdescription(): String? {
      return description
   }
   fun setdescription(description: String?) {
      this.description = description!!
   }

}