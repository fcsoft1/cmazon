package com.example.ecomm.api.get_categories

import com.example.ecomm.pojo.Chat

class GetCategoriesResponse(val status: Boolean, val message:String, val data: ArrayList<GetCategoriesData>)
