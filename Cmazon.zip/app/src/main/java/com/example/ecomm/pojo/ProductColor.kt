package com.example.ecomm.pojo

class ProductColor(color: String?, id: String?) {
   private var color: String= ""
   private var id: String= ""
   init {
      this.color = color!!
      this.id = id!!
   }
   fun getcolor(): String? {
      return color
   }
   fun setcolor(color: String?) {
      this.color = color!!
   }

   fun getid(): String? {
      return id
   }
   fun setid(genre: String?) {
      this.id = id!!
   }
}