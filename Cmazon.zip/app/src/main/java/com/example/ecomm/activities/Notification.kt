package com.example.ecomm.activities

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecomm.R
import com.example.ecomm.adapter.AdapterCategory
import com.example.ecomm.adapter.AdapterNotification
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.change_notification.ChangeNotificationData
import com.example.ecomm.api.change_notification.ChangeNotificationRequest
import com.example.ecomm.api.change_notification.ChangeNotificationResponse
import com.example.ecomm.api.view_all_address.ViewAllAddressRequest
import com.example.ecomm.api.view_all_address.ViewAllAddressResponse
import com.example.ecomm.pojo.Category
import com.example.ecomm.pojo.Notification
import kotlinx.android.synthetic.main.activity_add_address.*
import kotlinx.android.synthetic.main.activity_categories.*
import kotlinx.android.synthetic.main.activity_notification.*
import kotlinx.android.synthetic.main.activity_notification.img_back
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Notification : AppCompatActivity() {
    private val ar_notification = ArrayList<Notification>()
    private lateinit var notificationAdapter: AdapterNotification
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()

        lin_back.setOnClickListener( View.OnClickListener {
            finish()
        })


    }
    private fun GetAllNotifications() {


        val progressDialog = ProgressDialog(this@Notification)
        progressDialog.setTitle("Waiting")
        progressDialog.setMessage("Please wait...")
        progressDialog.show()
        ApiService.ApiCall().changeNotification("1"
        ).enqueue(object : Callback<ChangeNotificationData> {
            override fun onResponse(
                call: Call<ChangeNotificationData>,
                response: Response<ChangeNotificationData>
            ) {
                progressDialog.dismiss()
//                for(i in response.body()!!.data.indices) {
//                    val array_data = response.body()!!.data.get(i);
//                    // Notification
//                    var obj = Notification(
//                        "09:35 am",
//                        "One step ahead with new Stylish collections every week.",
//                        ""
//                    )
//                    ar_notification.add(obj)
//                }

//                notificationAdapter = AdapterNotification(ar_notification,applicationContext)
//                val layoutManager2 = LinearLayoutManager(applicationContext)
//                rec_notification.layoutManager = layoutManager2
//                rec_notification.itemAnimator = DefaultItemAnimator()
//                rec_notification.adapter = notificationAdapter
            }

            override fun onFailure(call: Call<ChangeNotificationData>, t: Throwable) {
                progressDialog.dismiss()
            }

        })
    }
}