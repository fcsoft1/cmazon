package com.example.ecomm.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.ecomm.R
import kotlinx.android.synthetic.main.activity_edit_profile.*

class EditProfile : AppCompatActivity(R.layout.activity_edit_profile) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        btn_continue.setOnClickListener( View.OnClickListener {
            finish()
        })

        lin_back.setOnClickListener( View.OnClickListener {
            finish()
        })
    }
}