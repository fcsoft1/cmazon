package com.example.ecomm.api.get_product;


import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ProductData {

    @SerializedName("status")
    public Integer status;

    @SerializedName("message")
    public String message;

    @SerializedName("data")
    public List<Data> data;

    public static class Data {
        @SerializedName("brand_name")
        private String brand_name;

        @SerializedName("category_name")
        private String category_name;

        @SerializedName("updated_at")
        private String updated_at;

        @SerializedName("created_at")
        private String created_at;

        @SerializedName("status")
        private String status;

        @SerializedName("discount")
        private String discount;

        @SerializedName("description")
        private String description;

        @SerializedName("price")
        private String price;

        @SerializedName("category")
        private String category;

        @SerializedName("shop_name")
        private String shop_name;

        @SerializedName("brand")
        private String brand;

        @SerializedName("title")
        private String title;

        @SerializedName("id")
        private String id;

        @SerializedName("rating")
        private String rating;

        @SerializedName("product_photo")
        private String product_photo;


        public String getBrand_name() {
            return brand_name;
        }

        public void setBrand_name(String brand_name) {
            this.brand_name = brand_name;
        }

        public String getCategory_name() {
            return category_name;
        }

        public void setCategory_name(String category_name) {
            this.category_name = category_name;
        }

        public String getUpdated_at() {
            return updated_at;
        }

        public void setUpdated_at(String updated_at) {
            this.updated_at = updated_at;
        }

        public String getCreated_at() {
            return created_at;
        }

        public void setCreated_at(String created_at) {
            this.created_at = created_at;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getDiscount() {
            return discount;
        }

        public void setDiscount(String discount) {
            this.discount = discount;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }

        public String getShop_name() {
            return shop_name;
        }

        public void setShop_name(String shop_name) {
            this.shop_name = shop_name;
        }

        public String getBrand() {
            return brand;
        }

        public void setBrand(String brand) {
            this.brand = brand;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getRating() {
            return rating;
        }

        public void setRating(String rating) {
            this.rating = rating;
        }

        public String getProduct_photo() {
            return product_photo;
        }

        public void setProduct_photo(String rating) {
            this.product_photo = product_photo;
        }
    }

}
