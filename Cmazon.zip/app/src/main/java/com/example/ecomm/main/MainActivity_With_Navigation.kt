package com.example.ecomm.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.fragment.app.Fragment
import com.example.ecomm.R
import com.example.ecomm.fragments.*
import kotlinx.android.synthetic.main.activity_main__with__navigation.*

class MainActivity_With_Navigation : AppCompatActivity(R.layout.activity_main__with__navigation) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()

        val home= Home()
        val myFavorite=MyFavorite()
        val categories= Categorie()
        val cart=Cart()
        val account=Account()

        if(intent.getBooleanExtra("from_product_details",false)) {
            setCurrentFragment(cart)
            bottomNavigationView.selectedItemId=R.id.navigation_cart
        }else{
            setCurrentFragment(home)
        }

        bottomNavigationView.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.navigation_home->setCurrentFragment(home)
                R.id.navigation_fav->setCurrentFragment(myFavorite)
                R.id.navigation_categories->setCurrentFragment(categories)
                R.id.navigation_cart->setCurrentFragment(cart)
                R.id.navigation_account->setCurrentFragment(account)

            }
            true
        }

    }

    private fun setCurrentFragment(fragment: Fragment)=
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.flFragment,fragment)
            commit()
        }
    }