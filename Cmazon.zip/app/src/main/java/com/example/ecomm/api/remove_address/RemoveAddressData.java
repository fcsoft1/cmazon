package com.example.ecomm.api.remove_address;

public class RemoveAddressData {

}
