package com.example.ecomm.api.remove_fav_product

import com.google.gson.annotations.SerializedName

class RemoveFavProductRequest(@SerializedName("product_id") var product_id: String)