package com.example.ecomm.api

import com.example.ecomm.api.add_address.AddAddressRequest
import com.example.ecomm.api.add_address.AddAddressResponse
import com.example.ecomm.api.change_notification.ChangeNotificationData
import com.example.ecomm.api.change_notification.ChangeNotificationRequest
import com.example.ecomm.api.change_notification.ChangeNotificationResponse
import com.example.ecomm.api.get_brands.GetBrandData
import com.example.ecomm.api.get_brands.GetBrandResponse
import com.example.ecomm.api.get_brands.GetBrandsRequest
import com.example.ecomm.api.get_categories.GetCategoriesData
import com.example.ecomm.api.get_categories.GetCategoriesRequest
import com.example.ecomm.api.get_categories.GetCategoriesResponse
import com.example.ecomm.api.get_home.GetHomeData
import com.example.ecomm.api.get_home.GetHomeRequest
import com.example.ecomm.api.get_home.GetHomeResponse
import com.example.ecomm.api.get_offers.GetOffersData
import com.example.ecomm.api.get_offers.GetOffersRequest
import com.example.ecomm.api.get_offers.GetOffersResponse
import com.example.ecomm.api.get_product.GetProductRequest
import com.example.ecomm.api.get_product.GetProductResponse
import com.example.ecomm.api.get_product.ProductData
import com.example.ecomm.api.get_product_details.ProductDetailsData
import com.example.ecomm.api.remove_address.RemoveAddressRequest
import com.example.ecomm.api.remove_address.RemoveAddressResponse
import com.example.ecomm.api.remove_fav_product.RemoveFavProductRequest
import com.example.ecomm.api.signin.SignInData
import com.example.ecomm.api.signin.SigninRequest
import com.example.ecomm.api.signin.SigninResponse
import com.example.ecomm.api.signup.SignUpData
import com.example.ecomm.api.signup.SignupRequest
import com.example.ecomm.api.signup.SignupResponse
import com.example.ecomm.api.view_all_address.ViewAllAddressRequest
import com.example.ecomm.api.view_all_address.ViewAllAddressResponse
import com.google.gson.annotations.SerializedName
import retrofit2.Call
import retrofit2.http.*

interface ApiList {

    //TODO : Login User
    @POST("ws/v1/user/login")
    @FormUrlEncoded
    fun doLogin(
        @Field("email")  email: String, @Field("password")  password: String
    ): Call<SignInData> // body data

    //TODO : Register User
    @POST("ws/v1/user/register_user")
    @FormUrlEncoded
    fun doRegister(@Field("fullname") fullname: String,
                   @Field("email") email: String,
                   @Field("password") password: String,
                   @Field("confirm_password") confirm_password: String,
                   @Field("country") country: String,
                   @Field("mobile") mobile: String,
                   @Field("referral_code") referral_code: String): Call<SignUpData> // body data

    //TODO : Add Address
    @POST("ws/v1/user/add_address")
    fun addAddress(
        @Body addaddressRequest: AddAddressRequest
    ): Call<AddAddressResponse> // body data


    //TODO : View All Address
    @POST("ws/v1/user/list_all_addresses")
    fun viewAllAddress(
        @Body viewAllAddressRequest: ViewAllAddressRequest
    ): Call<ViewAllAddressResponse> // body data


    //TODO : Remove Address
    @POST("ws/v1/user/remove_address")
    fun removeAddress(
        @Body removeAddressRequest: RemoveAddressRequest
    ): Call<RemoveAddressResponse> // body data

    //TODO : Remove Fav Product
    @POST("ws/v1/user/add_remove_fav_product")
    fun removeFavProduct(
        @Body removeFavProductRequest: RemoveFavProductRequest
    ): Call<RemoveFavProductRequest> // body data


    //TODO : ChangeNotification Setting
    @POST("ws/v1/user/change_notification")
    fun changeNotification(@Field("status") status: String): Call<ChangeNotificationData> // body data


    //TODO : Get Offers
    @POST("ws/v1/user/get_offers")
    fun getOffers(): Call<GetOffersData> // body data

    //TODO : Get Home
    @GET("ws/v1/user/home")
    fun getHome(): Call<GetHomeData> // body data

    //TODO : Get Categories
    @POST("ws/v1/user/get_categories")
    @FormUrlEncoded
    fun getCategories(@Field("email")  email: String): Call<GetCategoriesData> // body data

    //TODO : Get Product Details
    @POST("ws/v1/user/get_products_details")
    @FormUrlEncoded
    fun getProductDetails(@Field("product_id")  product_id: String): Call<ProductDetailsData> // body data

    //TODO : Get Product
    @POST("ws/v1/user/get_products")
    @FormUrlEncoded
    fun getProduct(@Field("brand") brand: String,
                   @Field("category") category: String,
                   @Field("shop") shop: String,
                   @Field("price") price: String): Call<ProductData> // body data



    //TODO : Get Brands
    @POST("ws/v1/user/get_brads")
    fun getBrands(
        @Body getBrandData: GetBrandsRequest
    ): Call<GetBrandResponse> // body data
}