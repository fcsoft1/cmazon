package com.example.ecomm.fragments

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.example.ecomm.R
import com.example.ecomm.activities.AddAddress
import com.example.ecomm.activities.Coupan
import com.example.ecomm.activities.EditProfile
import com.example.ecomm.activities.OrderPlaced
import kotlinx.android.synthetic.main.activity_cart.*

class Cart:Fragment(R.layout.activity_cart) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        add_address.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, AddAddress::class.java)
            startActivity(intent)
        })

        btn_continue.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, OrderPlaced::class.java)
            startActivity(intent)
        })

        txt_viewoffer.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, Coupan::class.java)
            intent.putExtra("apply_button",true)
            startActivity(intent)
        })

    }

}