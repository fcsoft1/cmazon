package com.example.ecomm.activities

import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecomm.R
import com.example.ecomm.adapter.AdapterColor
import com.example.ecomm.adapter.AdapterProductItem
import com.example.ecomm.adapter.AdapterProductSize
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.get_product.ProductData
import com.example.ecomm.api.get_product_details.ProductDetailsData
import com.example.ecomm.main.MainActivity_With_Navigation
import com.example.ecomm.pojo.ProductColor
import com.example.ecomm.pojo.ProductSize
import com.example.ecomm.pojo.Trending
import kotlinx.android.synthetic.main.activity_product__details.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Product_Details : AppCompatActivity(R.layout.activity_product__details) {
    private val ar_product_color = ArrayList<ProductColor>()
    private lateinit var productcolorAdapter: AdapterColor
    private val ar_product_size = ArrayList<ProductSize>()
    private val ar_trending = ArrayList<Trending>()
    private lateinit var trendingAdapter: AdapterProductItem
    private lateinit var productsizeAdapter: AdapterProductSize
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()

        product_comapny.setOnClickListener(View.OnClickListener {
            val intent = Intent(applicationContext, SearchResult::class.java)
            intent.putExtra("shop",product_comapny.text)
            intent.putExtra("shop_id","")
            startActivity(intent)
        })

        img_back.setOnClickListener(View.OnClickListener {
            finish()
        })

        add_to_cart.setOnClickListener(View.OnClickListener {
            val intent = Intent(applicationContext, MainActivity_With_Navigation::class.java)
            intent.putExtra("from_product_details",true)
            finish()
            startActivity(intent)
        })
        if(intent.getStringExtra("product_id")!=null){
            if(!intent.getStringExtra("product_id")?.isEmpty()!!){
//                GetProductDetails(intent.getStringExtra("product_id")!!)
            }
        }else{
            finish()
        }

        // Temp


        // Product Rate
        product_rate.setText("3.4")

        // Product Discount
        product_discount.setText("20%")

        // Product Company
        product_comapny.setText("From King lion Shop")

        // Product Name
        product_cat.setText("Hand-patinated leather")

        // Product Brand
        product_name.setText("Revenador")

        // Product Description
        txzt_lbl_product_overview_details.setText("Product Overview")


        // Product Color
        var obj = ProductColor("#000000", "")
        ar_product_color.add(obj)

        productcolorAdapter = AdapterColor(ar_product_color,applicationContext)
        rec_color.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.HORIZONTAL ,false)
        rec_color.itemAnimator = DefaultItemAnimator()
        rec_color.adapter = productcolorAdapter

        // Product Size
        var objx = ProductSize("41", "")
        ar_product_size.add(objx)

        productsizeAdapter = AdapterProductSize(ar_product_size,applicationContext)
        rec_product_size.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.HORIZONTAL ,false)
        rec_product_size.itemAnimator = DefaultItemAnimator()
        rec_product_size.adapter = productsizeAdapter


        // Recommanded Product
        var objy = Trending(
            "id", "Hand-patinated leather",
            "Named after a Filipino God of Thunder....", "500 CFA",
            "Revenador", "Upto 20% Discount", "3.6",
            "http://zestbrains4u.site/babiluxe/uploads/products/2d2192cbd1c9d969079d0bde1bdd1157.png"
        )
        var objy1 = Trending(
            "id", "Hand-patinated leather",
            "Named after a Filipino God of Thunder....", "500 CFA",
            "Revenador", "Upto 20% Discount", "3.6",
            "http://zestbrains4u.site/babiluxe/uploads/products/2d2192cbd1c9d969079d0bde1bdd1157.png"
        )
        var objy2 = Trending(
            "id", "Hand-patinated leather",
            "Named after a Filipino God of Thunder....", "500 CFA",
            "Revenador", "Upto 20% Discount", "3.6",
            "http://zestbrains4u.site/babiluxe/uploads/products/2d2192cbd1c9d969079d0bde1bdd1157.png"
        )
        ar_trending.add(objy)
        ar_trending.add(objy1)
        ar_trending.add(objy2)

        trendingAdapter = AdapterProductItem(ar_trending,0,applicationContext)
        rec_recommanded_product.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.HORIZONTAL ,false)
        rec_recommanded_product.itemAnimator = DefaultItemAnimator()
        rec_recommanded_product.adapter = trendingAdapter
    }
    private fun GetProductDetails(product_id: String) {
        val progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Waiting")
        progressDialog.setMessage("Please wait...")
        progressDialog.show()
        ApiService.ApiCall().getProductDetails(product_id).enqueue(object : Callback<ProductDetailsData> {
            override fun onResponse(
                call: Call<ProductDetailsData>,
                response: Response<ProductDetailsData>) {

                progressDialog.dismiss()
                Log.d("Response::::", response.body().toString())

                // Recommanded Product
//                GetRecomamdedSearch(response.body()!!.data.get(0).brand);
//
//                // Product Rate
//                product_rate.setText(response.body()!!.data.get(0).rating+" ")
//
//                // Product Discount
//                product_discount.setText(response.body()!!.data.get(0).discount+" ")
//
//                // Product Company
//                product_comapny.setText(response.body()!!.data.get(0).shop_name+" ")
//
//                // Product Name
//                product_cat.setText(response.body()!!.data.get(0).title+" ")
//
//                // Product Brand
//                product_name.setText(response.body()!!.data.get(0).brand_name+" ")
//
//                // Product Description
//                txzt_lbl_product_overview_details.setText(response.body()!!.data.get(0).description+" ")


                // Product Slider
                // passing this array list inside our adapter class.
//                val list2_slider
//                var adapter = SliderViewAdapter(applicationContext, list2_slider)
//                img_slider.setSliderAdapter(adapter)
//                img_slider.setInfiniteAdapterEnabled(true)
//                img_slider.setIndicatorAnimation(IndicatorAnimationType.WORM) //set indicator animation by using IndicatorAnimationType. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
//
//                img_slider.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION)
//                img_slider.autoCycleDirection = SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH
//                img_slider.indicatorSelectedColor = Color.WHITE
//                img_slider.indicatorUnselectedColor = Color.GRAY
//                img_slider.scrollTimeInSec = 4 //set scroll delay in seconds :
//
//                img_slider.startAutoCycle()

                // Product Color
                var obj = ProductColor("#000000", "")
                ar_product_color.add(obj)

                productcolorAdapter = AdapterColor(ar_product_color,applicationContext)
                rec_color.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.HORIZONTAL ,false)
                rec_color.itemAnimator = DefaultItemAnimator()
                rec_color.adapter = productcolorAdapter

                // Product Size
                var objx = ProductSize("41", "")
                ar_product_size.add(objx)

                productsizeAdapter = AdapterProductSize(ar_product_size,applicationContext)
                rec_product_size.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.HORIZONTAL ,false)
                rec_product_size.itemAnimator = DefaultItemAnimator()
                rec_product_size.adapter = productsizeAdapter


            }

            override fun onFailure(call: Call<ProductDetailsData>, t: Throwable) {
                progressDialog.dismiss()
            }

        })
    }
    private fun GetRecomamdedSearch(filter: String) {

        ApiService.ApiCall().getProduct(filter,"","",""
        ).enqueue(object : Callback<ProductData> {
            override fun onResponse(
                call: Call<ProductData>,
                response: Response<ProductData>
            ) {

                Log.d("Response::::", response.body().toString())
                for(i in response.body()!!.data.indices) {
                    val array_data = response.body()!!.data.get(i);
                    // Recommanded Product
                    var objy = Trending(
                        array_data.id+" ", array_data.shop_name+" ",
                        array_data.description+" ", array_data.price+" ",
                        array_data.brand_name+" ", array_data.discount+" ", array_data.rating+" ",
                        array_data.product_photo+" "
                    )
                    ar_trending.add(objy)
                }

                trendingAdapter = AdapterProductItem(ar_trending,4,applicationContext)
                rec_recommanded_product.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.HORIZONTAL ,false)
                rec_recommanded_product.itemAnimator = DefaultItemAnimator()
                rec_recommanded_product.adapter = trendingAdapter
//                }else{
//                    Toast.makeText(applicationContext, response.body()!!.message, Toast.LENGTH_LONG).show()
//                }
            }

            override fun onFailure(call: Call<ProductData>, t: Throwable) {
            }

        })
    }
}