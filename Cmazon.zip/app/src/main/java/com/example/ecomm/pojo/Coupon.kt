package com.example.ecomm.pojo

class Coupon(code: String?, title: String?, exp_date: String?, discount: String?) {
   private var code: String= ""
   private var title: String= ""
   private var exp_date: String= ""
   private var discount: String= ""
   init {
      this.title = title!!
      this.code = code!!
      this.exp_date = exp_date!!
      this.discount = discount!!
   }
   fun getTitle(): String? {
      return title
   }
   fun setTitle(name: String?) {
      title = name!!
   }
   fun getCode(): String? {
      return code
   }
   fun setCode(code: String?) {
      this.code = code!!
   }
   fun getExp_date(): String? {
      return exp_date
   }
   fun setExp_date(exp_date: String?) {
      this.exp_date = exp_date!!
   }
   fun getDiscount(): String? {
      return discount
   }
   fun setDiscount(discount: String?) {
      this.discount = discount!!
   }


}