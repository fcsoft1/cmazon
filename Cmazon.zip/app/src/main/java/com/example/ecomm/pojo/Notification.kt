package com.example.ecomm.pojo

class Notification(date: String?, title: String?, image: String?) {
   private var date: String= ""
   private var title: String= ""
   private var image: String= ""
   init {
      this.title = title!!
      this.image = image!!
      this.date = date!!
   }
   fun getTitle(): String? {
      return title
   }
   fun setTitle(name: String?) {
      this.title = name!!
   }

   fun getDate(): String? {
      return date
   }
   fun setDate(date: String?) {
      this.date = date!!
   }

   fun getImage(): String? {
      return image
   }
   fun setImage(genre: String?) {
      this.image = genre!!
   }
}