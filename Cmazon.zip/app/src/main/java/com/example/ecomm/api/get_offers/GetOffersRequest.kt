package com.example.ecomm.api.get_offers

import com.google.gson.annotations.SerializedName

class GetOffersRequest()