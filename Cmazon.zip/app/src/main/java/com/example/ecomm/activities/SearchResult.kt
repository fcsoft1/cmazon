package com.example.ecomm.activities

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecomm.R
import com.example.ecomm.adapter.AdapterProductItem
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.get_product.ProductData
import com.example.ecomm.pojo.Trending
import kotlinx.android.synthetic.main.activity_search_result.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SearchResult : AppCompatActivity() {
    private val ar_all_product = ArrayList<Trending>()
    private val ar_all_price = ArrayList<String>()
    private lateinit var all_productAdapter: AdapterProductItem
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_result)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()

        txt_category.setOnClickListener(View.OnClickListener {

            val intent = Intent(applicationContext,Categories::class.java)
            finish()
            startActivity(intent)
        })

        GetSearch()

        ar_all_price.add("Price : All");
        ar_all_price.add("Price : 0 to 10,000");
        ar_all_price.add("Price : 10,000 to 20,000");
        ar_all_price.add("Price : 20,000 to 30,000");
        ar_all_price.add("Price : 30,000 to 40,000");
        ar_all_price.add("Price : 40,000 to 50,000");
        ar_all_price.add("Price : 50,000+");

        var ar_adapter = ArrayAdapter<String>(applicationContext,android.R.layout.simple_dropdown_item_1line,ar_all_price);
        txt_price.adapter=ar_adapter
//        txt_price.setSel

        if(intent.getStringExtra("shop")!=null){
            if(!intent.getStringExtra("shop")?.isEmpty()!!){
                txt_search_label.visibility=View.VISIBLE
                txt_search_label.setText("Shop : "+intent.getStringExtra("shop")!!)
            }
        }
        if(intent.getStringExtra("brand")!=null){
            if(!intent.getStringExtra("brand")?.isEmpty()!!){
                txt_search_label.visibility=View.VISIBLE
                txt_search_label.setText("Brand : "+intent.getStringExtra("brand")!!)
            }
        }
    }
    private fun GetSearch() {
        val progressDialog = ProgressDialog(this@SearchResult)
        progressDialog.setTitle(getString(R.string.app_name))
        progressDialog.setMessage("Please wait...")
        progressDialog.show()
        var brand:String=""
        var shop:String=""
        var category:String=""
        var price:String=""
        if(intent.getStringExtra("category")!=null){
            if(!intent.getStringExtra("category")?.isEmpty()!!){
                category= intent.getStringExtra("category")!!
            }
        }
        if(intent.getStringExtra("shop_id")!=null){
            if(!intent.getStringExtra("shop_id")?.isEmpty()!!){
                shop= intent.getStringExtra("shop_id")!!
            }
        }
        if(intent.getStringExtra("brand_id")!=null){
            if(!intent.getStringExtra("brand_id")?.isEmpty()!!){
                brand= intent.getStringExtra("brand_id")!!
            }
        }
        if(txt_price.selectedItemPosition>0){
            price=ar_all_price.get(txt_price.selectedItemPosition)+""
        }
        ApiService.ApiCall().getProduct(brand,category,shop,price
        ).enqueue(object : Callback<ProductData> {
            override fun onResponse(
                call: Call<ProductData>,
                response: Response<ProductData>
            ) {
                progressDialog.dismiss()
                if(response.body()!=null) {
                    Log.d("Response::::", response.body().toString())
//                if (response.body()!!.status){
                    for (i in response.body()!!.data.indices) {
                        val array_data = response.body()!!.data.get(i);
                        var objy = Trending(
                            array_data.id + " ",
                            array_data.shop_name + " ",
                            array_data.description + " ",
                            array_data.price + " ",
                            array_data.brand_name + " ",
                            array_data.discount + " ",
                            array_data.rating + " ",
                            array_data.product_photo + " "
                        )
                        ar_all_product.add(objy)
                    }

                    all_productAdapter = AdapterProductItem(ar_all_product, 1, applicationContext)
                    val layoutManager2 = LinearLayoutManager(applicationContext)
                    rec_all_product.layoutManager = layoutManager2
                    rec_all_product.itemAnimator = DefaultItemAnimator()
                    rec_all_product.adapter = all_productAdapter
//                }else{
//                    Toast.makeText(applicationContext, response.body()!!.message, Toast.LENGTH_LONG).show()
//                }
                }else{
                    Toast.makeText(applicationContext,"No Record Found",Toast.LENGTH_SHORT).show()
                    finish()
                }
            }

            override fun onFailure(call: Call<ProductData>, t: Throwable) {
                progressDialog.dismiss()
            }

        })
    }
}