package com.example.ecomm.api.signup;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SignUpData {

    @SerializedName("status")
    public Integer status;

    @SerializedName("message")
    public String message;

    @SerializedName("data")
    public Data data;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    public class Data {

        
        @SerializedName("vAuthToken")
        private String vAuthToken;
        
        @SerializedName("referred_users")
        private String referred_users;
        
        @SerializedName("referral_code")
        private String referral_code;
        
        @SerializedName("country")
        private String country;
        
        @SerializedName("status")
        private String status;
        
        @SerializedName("profile_image")
        private String profile_image;
        
        @SerializedName("mobile")
        private String mobile;
        
        @SerializedName("email")
        private String email;
        
        @SerializedName("fullname")
        private String fullname;
        
        @SerializedName("id")
        private String id;

        public String getVAuthToken() {
            return vAuthToken;
        }

        public void setVAuthToken(String vAuthToken) {
            this.vAuthToken = vAuthToken;
        }

        public String getReferred_users() {
            return referred_users;
        }

        public void setReferred_users(String referred_users) {
            this.referred_users = referred_users;
        }

        public String getReferral_code() {
            return referral_code;
        }

        public void setReferral_code(String referral_code) {
            this.referral_code = referral_code;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getProfile_image() {
            return profile_image;
        }

        public void setProfile_image(String profile_image) {
            this.profile_image = profile_image;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getFullname() {
            return fullname;
        }

        public void setFullname(String fullname) {
            this.fullname = fullname;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }
}
