package com.example.ecomm.api.signin

import com.example.ecomm.pojo.Chat

class SigninResponse(val status: Boolean, val message:String, val data: ArrayList<SignInData>)
