package com.example.ecomm.api.signin;

import com.google.gson.annotations.SerializedName;

public class SignInData {

    @SerializedName("status")
    public Integer status;

    @SerializedName("message")
    public String message;

    @SerializedName("data")
    public Data data;

    public static class Data {
        
        @SerializedName("vAuthToken")
        public String vAuthToken;
        
        @SerializedName("referred_users")
        public String referred_users;
        
        @SerializedName("referral_code")
        public String referral_code;
        
        @SerializedName("country")
        public String country;
        
        @SerializedName("status")
        public String status;

        
        @SerializedName("profile_image")
        public String profile_image;
        
        @SerializedName("mobile")
        public String mobile;
        
        @SerializedName("email")
        public String email;
        
        @SerializedName("fullname")
        public String fullname;
        
        @SerializedName("id")
        public String id;

        public String getvAuthToken() {
            return vAuthToken;
        }

        public void setvAuthToken(String vAuthToken) {
            this.vAuthToken = vAuthToken;
        }

        public String getReferred_users() {
            return referred_users;
        }

        public void setReferred_users(String referred_users) {
            this.referred_users = referred_users;
        }

        public String getReferral_code() {
            return referral_code;
        }

        public void setReferral_code(String referral_code) {
            this.referral_code = referral_code;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String isStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getProfile_image() {
            return profile_image;
        }

        public void setProfile_image(String profile_image) {
            this.profile_image = profile_image;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getFullname() {
            return fullname;
        }

        public void setFullname(String fullname) {
            this.fullname = fullname;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }
}
