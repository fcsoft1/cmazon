package com.example.ecomm.activities

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.ecomm.R
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.ApiWorker
import com.example.ecomm.api.signin.SignInData
import com.example.ecomm.main.MainActivity_With_Navigation
import com.facebook.AccessToken
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import com.facebook.login.widget.LoginButton
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Login : AppCompatActivity() {

    var password_show : Boolean = false;
    lateinit var callbackManager: CallbackManager
    private val EMAIL = "email"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val window: Window = getWindow()
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.login_status_bar))

        supportActionBar?.hide();
        val btn_continue = findViewById<Button>(R.id.btn_continue);

        img_show_hide_pass.setOnClickListener(View.OnClickListener {
            if(password_show){
                password_show=false
                edt_pass.inputType = InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD;
                edt_pass.transformationMethod= PasswordTransformationMethod.getInstance()
                img_show_hide_pass.setImageResource(R.drawable.show_pass)
            }else{
                password_show=true
                edt_pass.inputType = InputType.TYPE_CLASS_TEXT;
                edt_pass.transformationMethod=null
                img_show_hide_pass.setImageResource(R.drawable.hide_pass)
            }
        })

        btn_continue.setOnClickListener(View.OnClickListener {
            var isValid : Boolean = true;
            if(edt_email.text.isEmpty()){
                isValid=false
                showDialog("Validation","Email Empty not allowd",this)
                return@OnClickListener
            }
            if(edt_pass.text.isEmpty()){
                isValid=false
                showDialog("Validation","Password Empty not allowd",this)
                return@OnClickListener
            }
            if(edt_pass.text.length<5){
                isValid=false
                showDialog("Validation","Password length should be minimum 5 char.",this)
                return@OnClickListener
            }

            if(isValid) {
//                val intent = Intent(applicationContext, MainActivity_With_Navigation::class.java)
//                finish()
//                startActivity(intent)
                getLogin()
            }
        })
        txt_signup.setOnClickListener(View.OnClickListener {
            val intent = Intent(applicationContext,Signup::class.java)
            finish()
            startActivity(intent)
        })
        txt_forgotpass.setOnClickListener(View.OnClickListener {
            val intent = Intent(applicationContext,ForgotPassword::class.java)
            finish()
            startActivity(intent)
        })

        val loginButton = findViewById<LoginButton>(R.id.loginButton)
        loginButton.setOnClickListener {
            loginButton.setReadPermissions(listOf(EMAIL))
            callbackManager = CallbackManager.Factory.create()
            loginButton.registerCallback(callbackManager, object : FacebookCallback<LoginResult?> {
                override fun onSuccess(loginResult: LoginResult?) {
                    Log.d("MainActivity", "Facebook token: " + loginResult!!.accessToken.token)
                    startActivity(
                        Intent(
                            applicationContext,
                            MainActivity_With_Navigation::class.java
                        )
                    )// App code
                }
                override fun onCancel() { // App code
                }
                override fun onError(exception: FacebookException) { // App code
                }
            })
            callbackManager = CallbackManager.Factory.create()
            LoginManager.getInstance().registerCallback(callbackManager,
                object : FacebookCallback<LoginResult?> {
                    override fun onSuccess(loginResult: LoginResult?) {
                        // App code
                    }
                    override fun onCancel() {
                        // App code
                    }
                    override fun onError(exception: FacebookException) {
                        // App code
                    }
                    val accessToken = AccessToken.getCurrentAccessToken()
//                    accessToken != null && !accessToken.isExpired
                })

//                override fun onActivityResult(
//                    requestCode: Int,
//                    resultCode: Int,
//                    data: Intent?
//                ) {
//                    callbackManager.onActivityResult(requestCode, resultCode, data)
//                    super.onActivityResult(requestCode, resultCode, data)
//                    callbackManager.onActivityResult(requestCode, resultCode, data)
//                })
        }
    }
    fun showDialog(title: String,dialogMessage: String, context: Context) {
        val builder = AlertDialog.Builder(context)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(dialogMessage)
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        //performing positive action
        builder.setPositiveButton("Ok"){dialogInterface, which ->

        }
        // Create the AlertDialog
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()

    }
    private fun getLogin() {
        val progressDialog = ProgressDialog(this@Login)
        progressDialog.setTitle(getString(R.string.app_name))
        progressDialog.setMessage("Please wait...")
        progressDialog.show()
        ApiService.ApiCall().doLogin(
                edt_email.text.toString(), edt_pass.text.toString()
        ).enqueue(object : Callback<SignInData> {
            override fun onResponse(
                call: Call<SignInData>,
                response: Response<SignInData>
            ) {
                progressDialog.dismiss()
                if(response.body() != null) {
                    Log.d("Response::::", response.body().toString())
                    if (response.body()?.status == 200) {
                        val sp: SharedPreferences =
                            getSharedPreferences("app", Context.MODE_PRIVATE)
                        val spEdit = sp.edit()
                        spEdit.putString("fullname", response.body()!!.data.fullname)
                        spEdit.putString("country", response.body()!!.data.country)
                        spEdit.putString("email", response.body()!!.data.email)
                        spEdit.putString("id", response.body()!!.data.id)
                        spEdit.putString("mobile", response.body()!!.data.mobile)
                        spEdit.putString("profile_image", response.body()!!.data.profile_image)
                        spEdit.putString("referral_code", response.body()!!.data.referral_code)
                        spEdit.putString("referred_users", response.body()!!.data.referred_users)
                        spEdit.putString("vAuthToken", response.body()!!.data.vAuthToken)
                        spEdit.putString("status", response.body()!!.data.status)
                        spEdit.commit()
                        ApiWorker.apiKey = response.body()!!.data.vAuthToken;

                        val intent = Intent(this@Login, MainActivity_With_Navigation::class.java)
                        finish()
                        startActivity(intent)
                    } else {
                        Toast.makeText(
                            applicationContext,
                            response.body()!!.message,
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }else{
                    Toast.makeText(
                        applicationContext,
                        "Username or Password Wrong",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<SignInData>, t: Throwable) {
                Log.d("Response::::", t.message.toString())
                progressDialog.dismiss()
            }

        })
    }

}