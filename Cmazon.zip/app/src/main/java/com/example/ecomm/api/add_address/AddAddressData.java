package com.example.ecomm.api.add_address;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AddAddressData {

}
