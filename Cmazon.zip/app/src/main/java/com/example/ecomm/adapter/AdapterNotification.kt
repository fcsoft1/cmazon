package com.example.ecomm.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ecomm.R
import com.example.ecomm.activities.Product_Details
import com.example.ecomm.activities.SearchResult
import com.example.ecomm.pojo.Brands
import com.example.ecomm.pojo.Category
import com.example.ecomm.pojo.Notification

class AdapterNotification(private val dataSet: ArrayList<Notification>, private val context: Context?) :
        RecyclerView.Adapter<AdapterNotification.ViewHolder>() {

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var img_icon = view.findViewById<ImageView>(R.id.img_icon)
        var txt_text = view.findViewById<TextView>(R.id.txt_text)
        var txt_date = view.findViewById<TextView>(R.id.txt_date)
        var lin_mainview = view.findViewById<LinearLayout>(R.id.lin_mainview)
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        val view = LayoutInflater.from(context)
                .inflate(R.layout.adapter_notification, viewGroup, false)

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val obj=dataSet[position];
        viewHolder?.txt_text?.text = obj.getTitle()
        viewHolder?.txt_date?.text = obj.getDate()

        viewHolder?.lin_mainview.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, SearchResult::class.java)
            context?.startActivity(intent)
        })
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = dataSet.size

}
