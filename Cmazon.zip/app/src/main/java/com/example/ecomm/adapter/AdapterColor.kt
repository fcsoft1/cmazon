package com.example.ecomm.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ecomm.R
import com.example.ecomm.activities.Product_Details
import com.example.ecomm.activities.SearchResult
import com.example.ecomm.pojo.Brands
import com.example.ecomm.pojo.ProductColor

class AdapterColor(private val dataSet: ArrayList<ProductColor>?,
                   private val context: Context?) :
        RecyclerView.Adapter<AdapterColor.ViewHolder>() {

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var img_propic = view.findViewById<ImageView>(R.id.img_propic)
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        val view = LayoutInflater.from(context)
                .inflate(R.layout.adapter_color_product, viewGroup, false)

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val obj= this!!.dataSet!![position];
        viewHolder?.img_propic?.setImageResource(Color.parseColor(obj.getcolor()))

    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = dataSet!!.size

}
