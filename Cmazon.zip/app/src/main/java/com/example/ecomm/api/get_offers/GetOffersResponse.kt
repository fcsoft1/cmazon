package com.example.ecomm.api.get_offers

import com.example.ecomm.pojo.Chat

class GetOffersResponse(val status: Boolean, val message:String, val data: ArrayList<GetOffersData>)
