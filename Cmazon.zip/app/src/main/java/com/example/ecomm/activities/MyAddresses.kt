package com.example.ecomm.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.example.ecomm.R
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.add_address.AddAddressRequest
import com.example.ecomm.api.add_address.AddAddressResponse
import com.example.ecomm.api.view_all_address.ViewAllAddressRequest
import com.example.ecomm.api.view_all_address.ViewAllAddressResponse
import kotlinx.android.synthetic.main.activity_add_address.*
import kotlinx.android.synthetic.main.activity_my_addresses.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MyAddresses : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_addresses)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()

        lin_addaddress.setOnClickListener( View.OnClickListener {
            val intent = Intent(applicationContext,AddAddress::class.java)
//            intent.putExtra("from_signup",true)
            startActivity(intent)
        })
        lin_back.setOnClickListener( View.OnClickListener {
            finish()
        })
    }

    private fun GetAllAddress() {

        ApiService.ApiCall().viewAllAddress(
            ViewAllAddressRequest()
        ).enqueue(object : Callback<ViewAllAddressResponse> {
            override fun onResponse(
                call: Call<ViewAllAddressResponse>,
                response: Response<ViewAllAddressResponse>
            ) {

                Log.d("Response::::", response.body().toString())
                if (response.body()!!.status){
                    Toast.makeText(applicationContext,response.body()!!.data.get(0).id+"", Toast.LENGTH_SHORT).show()

                }else{
                    Toast.makeText(applicationContext, response.body()!!.message, Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<ViewAllAddressResponse>, t: Throwable) {
            }

        })
    }
}