package com.example.ecomm.api.view_all_address

import com.google.gson.annotations.SerializedName

class ViewAllAddressRequest()