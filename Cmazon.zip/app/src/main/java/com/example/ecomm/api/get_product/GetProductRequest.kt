package com.example.ecomm.api.get_product

import com.google.gson.annotations.SerializedName

class GetProductRequest(@SerializedName("brand") var brand: String,
                        @SerializedName("category") var category: String,
                        @SerializedName("shop") var shop: String,
                        @SerializedName("price") var price: String)

