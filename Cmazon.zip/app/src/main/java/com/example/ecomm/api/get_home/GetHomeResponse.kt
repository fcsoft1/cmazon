package com.example.ecomm.api.get_home

import com.example.ecomm.pojo.Chat

class GetHomeResponse(val status: Boolean, val message:String, val data: GetHomeData)
