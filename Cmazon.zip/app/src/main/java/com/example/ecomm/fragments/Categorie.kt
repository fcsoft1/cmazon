package com.example.ecomm.fragments

import android.app.Activity
import android.app.ProgressDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecomm.R
import com.example.ecomm.adapter.AdapterCategory
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.get_categories.GetCategoriesData
import com.example.ecomm.pojo.Category
import kotlinx.android.synthetic.main.activity_categories.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Categorie:Fragment(R.layout.activity_categories) {
    private val ar_category = ArrayList<Category>()
    private lateinit var categoryAdapter: AdapterCategory
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        img_back.setOnClickListener(View.OnClickListener {
//            finish()
        })
        GetCategory(activity)
    }
    private fun GetCategory(activity: Activity?) {
        ar_category.clear()
        val progressDialog = ProgressDialog(activity)
        progressDialog.setTitle(getString(R.string.app_name))
        progressDialog.setMessage("Please wait...")
        progressDialog.show()
        ApiService.ApiCall().getCategories("").
        enqueue(object : Callback<GetCategoriesData> {
            override fun onResponse(
                call: Call<GetCategoriesData>,
                response: Response<GetCategoriesData>
            ) {
                progressDialog.dismiss()
                Log.d("Response::::", response.body().toString())
//                if (response.body()!!.status){
                    for(i in response.body()!!.data.indices){
                        val array_data=response.body()!!.data.get(i);
                        var obj = Category(array_data.id, array_data.name, array_data.image)
                        ar_category.add(obj)
                    }
                    categoryAdapter = AdapterCategory(ar_category,activity,false)
                    val layoutManager2 = LinearLayoutManager(context)
                    rec_category.layoutManager = layoutManager2
                    rec_category.itemAnimator = DefaultItemAnimator()
                    rec_category.adapter = categoryAdapter

//                }else{
//                    Toast.makeText(context, response.body()!!.message, Toast.LENGTH_LONG).show()
//                }
            }

            override fun onFailure(call: Call<GetCategoriesData>, t: Throwable) {
                Log.d("Response::::", t.message.toString())
                progressDialog.dismiss()
            }

        })
    }
}