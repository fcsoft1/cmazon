package com.example.ecomm.constant;

import android.view.Window;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextKt;

import com.example.ecomm.R;

public class Constant {


}
