package com.example.ecomm.api.get_product

import com.example.ecomm.pojo.Chat

class GetProductResponse(val status: Boolean, val message:String, val data: ArrayList<ProductData>)
