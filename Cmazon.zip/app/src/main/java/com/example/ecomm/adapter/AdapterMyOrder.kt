package com.example.ecomm.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ecomm.R
import com.example.ecomm.activities.MyOrderDetails
import com.example.ecomm.activities.RatingProduct
import com.example.ecomm.pojo.MyOrderView

class AdapterMyOrder(private val dataSet: ArrayList<MyOrderView>, private val design:Int, private val context: Context?) :
        RecyclerView.Adapter<AdapterMyOrder.ViewHolder>() {

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val lin_mainview = view.findViewById<LinearLayout>(R.id.lin_mainview)
        val txt_order_number = view.findViewById<TextView>(R.id.txt_order_number)
        val txt_order_date = view.findViewById<TextView>(R.id.txt_order_date)
        val txt_order_status = view.findViewById<TextView>(R.id.txt_order_status)
        val rec_order_item = view.findViewById<RecyclerView>(R.id.rec_order_item)

    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        var view : View = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.adpter_myorder, viewGroup, false);

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val obj=dataSet[position];

        viewHolder.txt_order_number?.text = obj.getOrderNo()
        viewHolder.txt_order_date?.text = obj.getDate()
        viewHolder.txt_order_status?.text = obj.getStatus()
        val orderitem=obj.getorderData();
        val myOrderAdapter = orderitem?.let { AdapterMyOrdersItem(it,2,context,obj.getType().toString()) }
        val layoutManager2 = LinearLayoutManager(context)
        viewHolder.rec_order_item.layoutManager = layoutManager2
        viewHolder.rec_order_item.itemAnimator = DefaultItemAnimator()
        viewHolder.rec_order_item.adapter = myOrderAdapter

        if(!obj.getType().toString().equals("1")){
            viewHolder.txt_order_status?.visibility=View.GONE
        }
        viewHolder.lin_mainview.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, MyOrderDetails::class.java)
            context?.startActivity(intent)
        })
//        viewHolder.img_product_photo.set = obj.getTitle()
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = dataSet.size

}
