package com.example.ecomm.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.ecomm.R
import com.example.ecomm.main.MainActivity_With_Navigation
import kotlinx.android.synthetic.main.activity_my_order_details.*

class MyOrderDetails : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_order_details)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()

        btn_chat_support.setOnClickListener(View.OnClickListener {
            val intent = Intent(applicationContext, ChatSupport::class.java)
            startActivity(intent)
        })
        img_back.setOnClickListener(View.OnClickListener {
            finish()
        })
    }
}