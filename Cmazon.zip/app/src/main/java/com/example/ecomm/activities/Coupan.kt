package com.example.ecomm.activities

import android.app.Activity
import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecomm.R
import com.example.ecomm.adapter.AdapterCoupon
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.get_offers.GetOffersData
import com.example.ecomm.pojo.Coupon
import kotlinx.android.synthetic.main.activity_coupan.*
import kotlinx.android.synthetic.main.activity_coupan.img_back
import kotlinx.android.synthetic.main.activity_notification.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Coupan : AppCompatActivity() {
    private val ar_coupon = ArrayList<Coupon>()
    private lateinit var couponAdapter: AdapterCoupon
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coupan)
        supportActionBar?.hide()

        img_back.setOnClickListener(View.OnClickListener {
            finish()
        })
        txt_back.setOnClickListener(View.OnClickListener {
            finish()
        })
        GetCoupan(this)

    }
    private fun GetCoupan(activity:Activity) {
        val progressDialog = ProgressDialog(this@Coupan)
        progressDialog.setTitle(getString(R.string.app_name))
        progressDialog.setMessage("Please wait...")
        progressDialog.show()
        ApiService.ApiCall().getOffers().enqueue(object : Callback<GetOffersData> {
            override fun onResponse(
                call: Call<GetOffersData>,
                response: Response<GetOffersData>
            ) {
                progressDialog.dismiss()
                Log.d("Response::::", response.body().toString())
//                if (response.body()!!.status){
                for(i in response.body()!!.data.indices) {
                    val array_data = response.body()!!.data.get(i);
                    // Coupon
                    var obj = Coupon(array_data.code, array_data.title, array_data.end_date, array_data.discount)
                    ar_coupon.add(obj)
                }

                couponAdapter = AdapterCoupon(ar_coupon,activity,intent.getBooleanExtra("apply_button",false))
                val layoutManager2 = LinearLayoutManager(applicationContext)
                rec_coupan.layoutManager = layoutManager2
                rec_coupan.itemAnimator = DefaultItemAnimator()
                rec_coupan.adapter = couponAdapter
//                }else{
//                    Toast.makeText(applicationContext, response.body()!!.message, Toast.LENGTH_LONG).show()
//                }
            }

            override fun onFailure(call: Call<GetOffersData>, t: Throwable) {
                progressDialog.dismiss()
            }

        })
    }
}