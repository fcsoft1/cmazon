package com.example.ecomm.api.signup

import com.example.ecomm.pojo.Chat

class SignupResponse(val status: Boolean, val message:String, val data: ArrayList<SignUpData>)
