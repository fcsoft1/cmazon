package com.example.ecomm.pojo

class ProductSize(text: String?, id: String?) {
   private var text: String= ""
   private var id: String= ""
   init {
      this.text = text!!
      this.id = id!!
   }
   fun gettext(): String? {
      return text
   }
   fun settext(text: String?) {
      this.text = text!!
   }

   fun getid(): String? {
      return id
   }
   fun setid(genre: String?) {
      this.id = id!!
   }
}