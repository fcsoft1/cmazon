package com.example.ecomm.api.signup

import com.google.gson.annotations.SerializedName

class SignupRequest(@SerializedName("fullname") var fullname: String,
                    @SerializedName("email") var email: String,
                    @SerializedName("password") var password: String,
                    @SerializedName("confirm_password") var confirm_password: String,
                    @SerializedName("country") var country: String,
                    @SerializedName("mobile") var mobile: String,
                    @SerializedName("referral_code") var referral_code: String)

