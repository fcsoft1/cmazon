package com.example.ecomm.pojo

class MyOrderView(OrderNo: String?,
                  Date: String?,
                  Status: String?,
                  ID: String?,
                  orderData: ArrayList<MyOrderItem>,
                  Type: String?) {
   private var OrderNo: String= ""
   private var Date: String= ""
   private var Status: String= ""
   private var ID: String= ""
   private var Type: String= ""
   private var orderData: ArrayList<MyOrderItem>? = null;
   init {
      this.OrderNo = OrderNo!!
      this.Date = Date!!
      this.Status = Status!!
      this.ID = ID!!
      this.orderData= orderData!!
      this.Type=Type!!
   }
   fun getOrderNo(): String? {
      return OrderNo
   }
   fun setOrderNo(OrderNo: String?) {
      this.OrderNo = OrderNo!!
   }
   fun getDate(): String? {
      return Date
   }
   fun setDate(Date: String?) {
      this.Date = Date!!
   }
   fun getStatus(): String? {
      return Status
   }
   fun setStatus(Status: String?) {
      this.Status = Status!!
   }
   fun getID(): String? {
      return ID
   }
   fun setID(ID: String?) {
      this.ID = ID!!
   }
   fun getType(): String? {
      return Type
   }
   fun setType(Type: String?) {
      this.Type = Type!!
   }


   fun getorderData(): ArrayList<MyOrderItem>? {
      return this.orderData
   }
   fun setorderData(ID: String?) {
      this.orderData = orderData!!
   }

}