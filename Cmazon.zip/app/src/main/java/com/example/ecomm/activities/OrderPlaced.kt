package com.example.ecomm.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.ecomm.R
import com.example.ecomm.main.MainActivity_With_Navigation
import kotlinx.android.synthetic.main.order_placed_successfuly.*

class OrderPlaced : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.order_placed_successfuly)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()
        btn_continue.setOnClickListener(View.OnClickListener {
            finish()
            val intent = Intent(applicationContext, MainActivity_With_Navigation::class.java)
            startActivity(intent)
        })
    }
}