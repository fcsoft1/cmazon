package com.example.ecomm.api.change_notification;

public class ChangeNotificationData {

}
