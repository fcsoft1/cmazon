package com.example.ecomm.api.get_offers;

import com.example.ecomm.api.get_product.ProductData;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetOffersData {

    @SerializedName("status")
    public Integer status;

    @SerializedName("message")
    public String message;

    @SerializedName("data")
    public List<Data> data;

    public static class Data {
        
        @SerializedName("updated_at")
        private String updated_at;
        
        @SerializedName("created_at")
        private String created_at;
        
        @SerializedName("coupon_for")
        private String coupon_for;
        
        @SerializedName("end_date")
        private String end_date;
        
        @SerializedName("start_date")
        private String start_date;
        
        @SerializedName("discount")
        private String discount;
        
        @SerializedName("title")
        private String title;
        
        @SerializedName("code")
        private String code;
        
        @SerializedName("id")
        private String id;

        public String getUpdated_at() {
            return updated_at;
        }

        public void setUpdated_at(String updated_at) {
            this.updated_at = updated_at;
        }

        public String getCreated_at() {
            return created_at;
        }

        public void setCreated_at(String created_at) {
            this.created_at = created_at;
        }

        public String getCoupon_for() {
            return coupon_for;
        }

        public void setCoupon_for(String coupon_for) {
            this.coupon_for = coupon_for;
        }

        public String getEnd_date() {
            return end_date;
        }

        public void setEnd_date(String end_date) {
            this.end_date = end_date;
        }

        public String getStart_date() {
            return start_date;
        }

        public void setStart_date(String start_date) {
            this.start_date = start_date;
        }

        public String getDiscount() {
            return discount;
        }

        public void setDiscount(String discount) {
            this.discount = discount;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }
}
