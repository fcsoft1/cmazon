package com.example.ecomm.pojo

class Chat(title: String?, type: String?) {
   private var title: String= ""
   private var type: String= ""
   init {
      this.title = title!!
      this.type = type!!
   }
   fun getTitle(): String? {
      return title
   }
   fun setTitle(name: String?) {
      title = name!!
   }

   fun gettype(): String? {
      return type
   }
   fun settype(type: String?) {
      this.type = type!!
   }
}