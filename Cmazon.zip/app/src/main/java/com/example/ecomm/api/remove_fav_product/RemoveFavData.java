package com.example.ecomm.api.remove_fav_product;

public class RemoveFavData {

}
