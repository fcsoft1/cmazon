package com.example.ecomm.api.get_brands

import com.google.gson.annotations.SerializedName

class GetBrandsRequest()