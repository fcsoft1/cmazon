package com.example.ecomm.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ecomm.R
import com.example.ecomm.activities.Product_Details
import com.example.ecomm.activities.SearchResult
import com.example.ecomm.pojo.Brands
import com.example.ecomm.pojo.Chat

class AdapterChat(private val dataSet: ArrayList<Chat>, private val context: Context?) :
        RecyclerView.Adapter<AdapterChat.ViewHolder>() {

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var txt_left = view.findViewById<TextView>(R.id.txt_left)
        var txt_right = view.findViewById<TextView>(R.id.txt_right)
        var lin_left = view.findViewById<LinearLayout>(R.id.lin_left)
        var lin_right = view.findViewById<LinearLayout>(R.id.lin_right)
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        val view = LayoutInflater.from(context)
                .inflate(R.layout.adapter_chat, viewGroup, false)

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val obj=dataSet[position];
        viewHolder?.txt_right?.text = obj.getTitle()
        viewHolder?.txt_left?.text = obj.getTitle()

        if(obj.gettype().toString().equals("1")){
            viewHolder?.lin_right?.visibility=View.GONE
            viewHolder?.lin_left?.visibility=View.VISIBLE
        }
        if(obj.gettype().toString().equals("2")){
            viewHolder?.lin_right?.visibility=View.VISIBLE
            viewHolder?.lin_left?.visibility=View.GONE
        }
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = dataSet.size

}
