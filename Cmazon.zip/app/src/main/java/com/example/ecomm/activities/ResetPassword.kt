package com.example.ecomm.activities

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.View
import androidx.appcompat.app.AlertDialog
import com.example.ecomm.R
import com.example.ecomm.main.MainActivity_With_Navigation
import kotlinx.android.synthetic.main.activity_reset_password.*

class ResetPassword : AppCompatActivity() {
    var password_show : Boolean = false;
    var password_show1 : Boolean = false;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()

        btn_continue.setOnClickListener( View.OnClickListener {
            var isValid : Boolean = true;
            if(edt_pass.text.isEmpty()){
                isValid=false
                showDialog("Validation","Password Empty not allowd",this)
                return@OnClickListener
            }

            if(edt_pass.text.length<9){
                isValid=false
                showDialog("Validation","Password length should be minimum 9 char.",this)
                return@OnClickListener
            }
            if(edt_pass1.text.isEmpty()){
                isValid=false
                showDialog("Validation","Re-Password Empty not allowd",this)
                return@OnClickListener
            }

            if(isValid) {
                val intent = Intent(applicationContext, MainActivity_With_Navigation::class.java)
                finish()
                startActivity(intent)
            }
        } )

        img_back.setOnClickListener( View.OnClickListener {
            finish()
        } )

        img_show_hide_pass.setOnClickListener(View.OnClickListener {
            if(password_show){
                password_show=false
                edt_pass.inputType = InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD;
                edt_pass.transformationMethod= PasswordTransformationMethod.getInstance()
                img_show_hide_pass.setImageResource(R.drawable.show_pass)
            }else{
                password_show=true
                edt_pass.inputType = InputType.TYPE_CLASS_TEXT;
                edt_pass.transformationMethod=null
                img_show_hide_pass.setImageResource(R.drawable.hide_pass)
            }
        })
        img_show_hide_pass1.setOnClickListener(View.OnClickListener {
            if(password_show1){
                password_show1=false
                edt_pass1.inputType = InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD;
                edt_pass1.transformationMethod= PasswordTransformationMethod.getInstance()
                img_show_hide_pass1.setImageResource(R.drawable.show_pass)
            }else{
                password_show1=true
                edt_pass1.inputType = InputType.TYPE_CLASS_TEXT;
                edt_pass1.transformationMethod=null
                img_show_hide_pass1.setImageResource(R.drawable.hide_pass)
            }
        })
    }
    fun showDialog(title: String,dialogMessage: String, context: Context) {
        val builder = AlertDialog.Builder(context)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(dialogMessage)
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        //performing positive action
        builder.setPositiveButton("Ok"){dialogInterface, which ->

        }

        // Create the AlertDialog
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()

    }
}