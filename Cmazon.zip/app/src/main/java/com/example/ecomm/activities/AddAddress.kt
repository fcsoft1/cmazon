package com.example.ecomm.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ecomm.R
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.add_address.AddAddressRequest
import com.example.ecomm.api.add_address.AddAddressResponse
import com.shivtechs.maplocationpicker.LocationPickerActivity
import com.shivtechs.maplocationpicker.MapUtility
import kotlinx.android.synthetic.main.activity_add_address.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class AddAddress : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_address)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()

        lin_close.setOnClickListener( View.OnClickListener {
            if(intent.getBooleanExtra("from_signup",false)){
//                val intent = Intent(applicationContext, MainActivity_With_Navigation::class.java)
//                startActivity(intent)
            }
            finish()
        })

        btn_continue.setOnClickListener( View.OnClickListener {
            if(intent.getBooleanExtra("from_signup",false)){
//                val intent = Intent(this@AddAddress, MainActivity_With_Navigation::class.java)
//                startActivity(intent)
            }
            finish()
        })

        txt_change.setOnClickListener(View.OnClickListener {
//            val i = Intent(this@AddAddress, LocationPickerActivity::class.java)
//            startActivityForResult(i, 0)
            Toast.makeText(applicationContext,"API Key Required",Toast.LENGTH_SHORT).show()
        })
    }
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0) {
            try {
                if (data != null && data.getStringExtra(MapUtility.ADDRESS) != null) {
                    // String address = data.getStringExtra(MapUtility.ADDRESS);
                    val currentLatitude =
                        data.getDoubleExtra(MapUtility.LATITUDE, 0.0)
                    val currentLongitude =
                        data.getDoubleExtra(MapUtility.LONGITUDE, 0.0)
                    val completeAddress = data.getBundleExtra("fullAddress")
                    /* data in completeAddress bundle
                    "fulladdress"
                    "city"
                    "state"
                    "postalcode"
                    "country"
                    "addressline1"
                    "addressline2"
                     */
//                    txtAddress.setText(
//                        StringBuilder().append("addressline2: ")
//                            .append(completeAddress!!.getString("addressline2")).append("\ncity: ")
//                            .append(completeAddress.getString("city")).append("\npostalcode: ")
//                            .append(completeAddress.getString("postalcode")).append("\nstate: ")
//                            .append(completeAddress.getString("state")).toString()
//                    )
//                    txtLatLong.setText(
//                        StringBuilder().append("Lat:").append(currentLatitude)
//                            .append("  Long:").append(currentLongitude).toString()
//                    )
                }
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }
    }
    override fun onBackPressed() {
        if(!intent.getBooleanExtra("from_signup",false)) {
            super.onBackPressed()
        }else{
            showDialog("Warning","Default address is must required.",applicationContext)

        }
    }
    fun showDialog(title: String,dialogMessage: String, context: Context) {
        val builder = AlertDialog.Builder(context)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(dialogMessage)
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        //performing positive action
        builder.setPositiveButton("Ok"){dialogInterface, which ->

        }

        // Create the AlertDialog
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()

    }
    private fun SaveAddress() {
        val option:String
        if(edt_tag1.tag.equals("1")){
            option=edt_tag1.text.toString()
        }else{
            option=edt_tag2.text.toString()
        }
        val type:String
        type="manual"

        ApiService.ApiCall().addAddress(
            AddAddressRequest(option,
            type,
            edt_house.text.toString(),
            edt_house.text.toString(),
            edt_area.text.toString(),
            edt_city.text.toString())
        ).enqueue(object : Callback<AddAddressResponse> {
            override fun onResponse(
                call: Call<AddAddressResponse>,
                response: Response<AddAddressResponse>
            ) {

                Log.d("Response::::", response.body().toString())
                if (response.body()!!.status){
//                    Toast.makeText(applicationContext,response.body()!!.data.get(0).id+"", Toast.LENGTH_SHORT).show()
                    val intent = Intent(applicationContext, OTP::class.java)
                    finish()
                    startActivity(intent)
                }else{
                    Toast.makeText(applicationContext, response.body()!!.message, Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<AddAddressResponse>, t: Throwable) {
            }

        })
    }
}