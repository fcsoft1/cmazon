package com.example.ecomm.fragments

import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import com.example.ecomm.R

import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecomm.activities.Coupan
import com.example.ecomm.activities.MyAddresses
import com.example.ecomm.activities.SearchResult
import com.example.ecomm.adapter.AdapterBrand
import com.example.ecomm.adapter.AdapterProductItem
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.get_home.GetHomeData
import com.example.ecomm.pojo.Brands
import com.example.ecomm.pojo.Trending
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_home.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Home:Fragment(R.layout.activity_home) {
    private val ar_brands = ArrayList<Brands>()
    private lateinit var moviesAdapter: AdapterBrand
    private val ar_trending = ArrayList<Trending>()
    private lateinit var trendingAdapter: AdapterProductItem
    private val ar_all_product = ArrayList<Trending>()
    private lateinit var all_productAdapter: AdapterProductItem
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        lin_offer.setOnClickListener( View.OnClickListener {
            val intent = Intent(context, Coupan::class.java)
            startActivity(intent)
        })

        lin_area.setOnClickListener( View.OnClickListener {
            val intent = Intent(context, MyAddresses::class.java)
            startActivity(intent)
        })

//        edt_search.setOnEditorActionListener{ v, actionId, event ->
//            if(actionId == EditorInfo.IME_ACTION_DONE){
//                val intent = Intent(context, SearchResult::class.java)
//                startActivity(intent)
//                true
//            } else {
//                false
//            }
//        }
        edt_search.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, SearchResult::class.java)
            startActivity(intent)
        })
        ar_brands.clear()
        ar_trending.clear()
        ar_all_product.clear()
        GetHome()
    }
    private fun GetHome() {
        val progressDialog = ProgressDialog(context)
        progressDialog.setTitle(getString(R.string.app_name))
        progressDialog.setMessage("Please wait...")
        progressDialog.show()

        ar_brands.clear()
        ar_trending.clear()
        ar_all_product.clear()

        ApiService.ApiCall().getHome().enqueue(object : Callback<GetHomeData> {
            override fun onResponse(
                call: Call<GetHomeData>,
                response: Response<GetHomeData>
            ) {
                progressDialog.dismiss()
                if(response.body()!=null) {
                    Log.d("Response::::", response.body().toString())
                    txt_quote.setText(response.body()!!.data.quote)
                    Picasso.with(context).load(response.body()!!.data.banner.banner_image)
                        .into(img_slider)
                    img_slider.setTag(response.body()!!.data.banner.banner_url)
                    img_slider.setOnClickListener(View.OnClickListener {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW)
                            intent.data = Uri.parse(img_slider.getTag().toString())
                            startActivity(intent)
                        }catch (E:Exception){

                        }
                    })

//                if (response.body()!!.status==200){
                    if (response.body()!!.data.brands != null) {
                        for (i in response.body()!!.data.brands.indices) {
                            val array_data = response.body()!!.data.brands.get(i);
                            // Brands
                            var obj = Brands(array_data.id, array_data.name, array_data.image)
                            ar_brands.add(obj)
                        }
                    }
                    moviesAdapter = AdapterBrand(ar_brands, context)
                    rec_brands.layoutManager =
                        LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
                    rec_brands.itemAnimator = DefaultItemAnimator()
                    rec_brands.adapter = moviesAdapter

                    if (response.body()!!.data.products != null) {
                        for (i in response.body()!!.data.products.indices) {
                            val array_data = response.body()!!.data.products.get(i);
                            // Tranding
                            var objy = Trending(
                                array_data.id, array_data.shop_name,
                                array_data.description, array_data.price,
                                array_data.brand_name, array_data.discount, array_data.rating,
                                array_data.product_photo
                            )
                            ar_trending.add(objy)
                        }
                    }
                    trendingAdapter = AdapterProductItem(ar_trending, 0, context)
                    rec_trading.layoutManager =
                        LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
                    rec_trading.itemAnimator = DefaultItemAnimator()
                    rec_trading.adapter = trendingAdapter

                    if (response.body()!!.data.products != null) {
                        for (i in response.body()!!.data.products.indices) {
                            val array_data = response.body()!!.data.products.get(i);
                            // All Products
                            var objy = Trending(
                                array_data.id, array_data.shop_name,
                                array_data.description, array_data.price,
                                array_data.brand_name, array_data.discount, array_data.rating,
                                array_data.product_photo
                            )
                            ar_all_product.add(objy)
                        }
                    }
                    all_productAdapter = AdapterProductItem(ar_all_product, 2, context)
                    val layoutManager2 = LinearLayoutManager(context)
                    rec_all_product.layoutManager = layoutManager2
                    rec_all_product.itemAnimator = DefaultItemAnimator()
                    rec_all_product.adapter = all_productAdapter
//                }else{
//                    Toast.makeText(context, response.body()!!.message, Toast.LENGTH_LONG).show()
//                }
                }
            }

            override fun onFailure(call: Call<GetHomeData>, t: Throwable) {
                Log.d("Response::::", t.message.toString())
                progressDialog.dismiss()
            }

        })
    }

}