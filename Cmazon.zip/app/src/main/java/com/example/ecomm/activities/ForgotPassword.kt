package com.example.ecomm.activities

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.ecomm.R
import kotlinx.android.synthetic.main.activity_forgot_password.*
import kotlinx.android.synthetic.main.activity_forgot_password.btn_continue
import kotlinx.android.synthetic.main.activity_forgot_password.edt_phone
import kotlinx.android.synthetic.main.activity_forgot_password.img_back
import kotlinx.android.synthetic.main.activity_signup.*

class ForgotPassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        supportActionBar?.hide()
        btn_continue.setOnClickListener( View.OnClickListener {
            var isValid : Boolean = true;
            if(edt_phone.text.isEmpty()){
                isValid=false
                showDialog("Validation","Please enter your phone number",this)
                return@OnClickListener

            }
            if(edt_phone.text.length<9){
                isValid=false
                showDialog("Validation","Phone number length should be minimum 10 char.",this)
                return@OnClickListener
            }

            val intent = Intent(applicationContext,OTP::class.java)
            intent.putExtra("fromforgotpass",true)
            intent.putExtra("mobile",edt_phone.text)
            finish()
            startActivity(intent)
        } )
        txt_login.setOnClickListener( View.OnClickListener {
            val intent = Intent(applicationContext,Login::class.java)
            finish()
            startActivity(intent)
            this.overridePendingTransition( R.anim.slide_in_up, R.anim.slide_out_up );
        } )
        img_back.setOnClickListener( View.OnClickListener {
            val intent = Intent(applicationContext,Login::class.java)
            finish()
            startActivity(intent)
            this.overridePendingTransition( R.anim.slide_in_up, R.anim.slide_out_up );
        } )
    }
    fun showDialog(title: String,dialogMessage: String, context: Context) {
        val builder = AlertDialog.Builder(context)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(dialogMessage)
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        //performing positive action
        builder.setPositiveButton("Ok"){dialogInterface, which ->

        }
        // Create the AlertDialog
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()

    }

    override fun onBackPressed() {
        val intent = Intent(applicationContext,Login::class.java)
        finish()
        startActivity(intent)
    }
}