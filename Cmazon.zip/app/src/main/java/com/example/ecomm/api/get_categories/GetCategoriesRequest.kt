package com.example.ecomm.api.get_categories

import com.google.gson.annotations.SerializedName

class GetCategoriesRequest()