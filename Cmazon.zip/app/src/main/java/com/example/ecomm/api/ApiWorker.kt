package com.example.ecomm.api
import android.content.Context
import android.util.Log
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import retrofit2.converter.gson.GsonConverterFactory
import java.security.KeyManagementException
import java.security.NoSuchAlgorithmException
import java.util.concurrent.TimeUnit

object ApiWorker {
    private var mClient: OkHttpClient? = null
    private var mGsonConverter: GsonConverterFactory? = null
    var apiKey: String? = ""
    /**
     * Don't forget to remove Interceptors (or change Logging Level to NONE)
     * in production! Otherwise people will be able to see your request and response on Log Cat.
     */
    val client: OkHttpClient
        @Throws(NoSuchAlgorithmException::class, KeyManagementException::class)
        get() {
            if (mClient == null) {



                val httpBuilder = OkHttpClient.Builder()
                httpBuilder
                    .connectTimeout(120, TimeUnit.SECONDS)
                    .readTimeout(120, TimeUnit.SECONDS)
//                    .addInterceptor(interceptor)  /// show all JSON in logCat
                    .addInterceptor { chain ->
                        val original = chain.request()
                        val requestBuilder = original.newBuilder()
//                        .addHeader("Authorization", AUTH)
                            .addHeader("Content-Type", "application/x-www-form-urlencoded")
                            .addHeader("Vauthtoken", "Bearer "+ apiKey)
//                            .method(original.method(), original.body())

                        val request = requestBuilder.build()
                        chain.proceed(request)
                    }
                mClient = httpBuilder.build()

            }
            return mClient!!
        }


    val gsonConverter: GsonConverterFactory
        get() {
            if (mGsonConverter == null) {
                mGsonConverter = GsonConverterFactory
                    .create(
//                        GsonBuilder()
//                            .setLenient()
//                            .disableHtmlEscaping()
//                            .create()
                    )
            }
            return mGsonConverter!!
        }
}