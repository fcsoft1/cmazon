package com.example.ecomm.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ecomm.R
import com.example.ecomm.activities.Product_Details
import com.example.ecomm.activities.SearchResult
import com.example.ecomm.pojo.Brands

class AdapterBrand(private val dataSet: ArrayList<Brands>, private val context: Context?) :
        RecyclerView.Adapter<AdapterBrand.ViewHolder>() {

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var txt_brand_name = view.findViewById<TextView>(R.id.txt_brand_name)
        var lin_mainview = view.findViewById<LinearLayout>(R.id.lin_mainview)
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        val view = LayoutInflater.from(context)
                .inflate(R.layout.adapter_brands, viewGroup, false)

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val obj=dataSet[position];
        viewHolder?.txt_brand_name?.text = obj.getTitle()

        viewHolder?.lin_mainview.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, SearchResult::class.java)
            intent.putExtra("brand",obj.getTitle())
            intent.putExtra("brand_id",obj.getId())
            context?.startActivity(intent)
        })
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = dataSet.size

}
