package com.example.ecomm.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecomm.R
import com.example.ecomm.adapter.AdapterBrand
import com.example.ecomm.adapter.AdapterChat
import com.example.ecomm.fragments.Cart
import com.example.ecomm.pojo.Brands
import com.example.ecomm.pojo.Chat
import kotlinx.android.synthetic.main.activity_chat_support.*

class ChatSupport : AppCompatActivity() {
    private val ar_chat = ArrayList<Chat>()
    private lateinit var moviesAdapter: AdapterChat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_support)
        supportActionBar?.hide()

        // Brands
        var obj = Chat("Hello, Are you there?", "1")
        ar_chat.add(obj)
        var obj1 = Chat("Yes please tell me..", "2")
        ar_chat.add(obj1)
        var obj2 = Chat("I am looking for Mens' shoes of 9\" size. Is this available?", "1")
        ar_chat.add(obj2)
        var obj3 = Chat("Yes, it is available.", "2")
        ar_chat.add(obj3)

        moviesAdapter = AdapterChat(ar_chat,applicationContext)
        val layoutManager2 = LinearLayoutManager(applicationContext)
        rec_chat.layoutManager = layoutManager2
        rec_chat.itemAnimator = DefaultItemAnimator()
        rec_chat.adapter = moviesAdapter

        img_back.setOnClickListener(View.OnClickListener {
            finish()
        })
    }
}