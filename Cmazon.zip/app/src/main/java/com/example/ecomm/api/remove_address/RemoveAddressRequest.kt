package com.example.ecomm.api.remove_address

import com.google.gson.annotations.SerializedName

class RemoveAddressRequest(@SerializedName("address_id") var address_id: String)