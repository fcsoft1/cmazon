package com.example.ecomm.api.get_brands;

public abstract class GetBrandData {

}
