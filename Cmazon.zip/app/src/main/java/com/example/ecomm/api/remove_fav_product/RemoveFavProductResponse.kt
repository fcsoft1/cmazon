package com.example.ecomm.api.remove_fav_product

import com.example.ecomm.pojo.Chat

class RemoveFavProductResponse(val status: Boolean, val message:String, val data: RemoveFavData)
