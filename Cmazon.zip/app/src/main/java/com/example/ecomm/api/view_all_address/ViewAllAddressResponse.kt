package com.example.ecomm.api.view_all_address

import com.example.ecomm.api.signup.SignUpData
import com.example.ecomm.pojo.Chat

class ViewAllAddressResponse(val status: Boolean, val message:String, val data: ArrayList<ViewAllAddressData>)
