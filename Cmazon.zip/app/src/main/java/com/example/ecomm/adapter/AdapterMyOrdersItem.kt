package com.example.ecomm.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ecomm.R
import com.example.ecomm.activities.OrderPlaced
import com.example.ecomm.activities.Product_Details
import com.example.ecomm.activities.RatingProduct
import com.example.ecomm.pojo.MyOrderItem

class AdapterMyOrdersItem(private val dataSet: ArrayList<MyOrderItem>,
                          private val design:Int,
                          private val context: Context?,
                          private val Type: String?) :
        RecyclerView.Adapter<AdapterMyOrdersItem.ViewHolder>() {

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

            val img_product_photo = view.findViewById<ImageView>(R.id.img_product_photo)
            val txt_company = view.findViewById<TextView>(R.id.txt_company)
            val txt_price = view.findViewById<TextView>(R.id.txt_price)
            val txt_label = view.findViewById<TextView>(R.id.txt_label)
            val txt_discount_label = view.findViewById<TextView>(R.id.txt_discount_label)
            val txt_rating = view.findViewById<TextView>(R.id.txt_rating)
            val txt_description = view.findViewById<TextView>(R.id.txt_description)
            val txt_review = view.findViewById<TextView>(R.id.txt_review)
            val lin_mainview = view.findViewById<LinearLayout>(R.id.lin_mainview)
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        var view : View = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.adpter_myorder_item, viewGroup, false);

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val obj= dataSet?.get(position);
        viewHolder?.txt_company?.text = obj?.getcompany()
        viewHolder?.txt_discount_label?.text = obj?.getdiscount_label()
        viewHolder?.txt_label?.text = obj?.getlabel()
        viewHolder?.txt_price?.text = obj?.getprice()
        viewHolder?.txt_rating?.text = obj?.getrating()
        viewHolder?.txt_description?.text = obj?.getdescription()
        if(!Type.equals("2")) {
            viewHolder?.txt_review?.visibility = View.GONE
        }

        viewHolder?.txt_review.setOnClickListener(View.OnClickListener {
            val intent = Intent(context, RatingProduct::class.java)
            context?.startActivity(intent)
        })
//        viewHolder.img_product_photo.set = obj.getTitle()
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = dataSet?.size

}
