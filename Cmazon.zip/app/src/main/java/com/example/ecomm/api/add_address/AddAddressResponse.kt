package com.example.ecomm.api.add_address

import com.example.ecomm.pojo.Chat

class AddAddressResponse(val status: Boolean, val message:String, val data: AddAddressData)
