package com.example.ecomm.fragments

import android.app.ProgressDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecomm.R
import com.example.ecomm.adapter.AdapterProductItem
import com.example.ecomm.api.ApiService
import com.example.ecomm.api.get_product.GetProductRequest
import com.example.ecomm.api.get_product.GetProductResponse
import com.example.ecomm.api.get_product.ProductData
import com.example.ecomm.pojo.Trending
import kotlinx.android.synthetic.main.activity_my_favorite.*
import kotlinx.android.synthetic.main.activity_my_favorite.rec_all_product
import kotlinx.android.synthetic.main.activity_search_result.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MyFavorite:Fragment(R.layout.activity_my_favorite) {
    private val ar_all_product = ArrayList<Trending>()
    private lateinit var all_productAdapter: AdapterProductItem
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        GetFavorite()
    }

    private fun GetFavorite() {
        ar_all_product.clear()
        val progressDialog = ProgressDialog(activity)
        progressDialog.setTitle(getString(R.string.app_name))
        progressDialog.setMessage("Please wait...")
        progressDialog.show()
        val brand:String=""
        val category:String=""
        val shop:String=""
        val price:String=""
        ApiService.ApiCall().getProduct(brand,category,shop,price
        ).enqueue(object : Callback<ProductData> {
            override fun onResponse(
                call: Call<ProductData>,
                response: Response<ProductData>
            ) {
                progressDialog.dismiss()
                Log.d("Response::::", response.body().toString())
//                if (response.body()!!.status){
                    for(i in response.body()!!.data.indices) {
                        val array_data=response.body()!!.data.get(i);
                        var objy = Trending(
                            array_data.id, array_data.shop_name+" ",
                            array_data.description+" ", array_data.price+" ",
                            array_data.brand_name+" ", array_data.discount+" ",
                            array_data.rating+" ",array_data.product_photo+" "
                        )
                        ar_all_product.add(objy)
                    }

                    all_productAdapter = AdapterProductItem(ar_all_product,2,context)
                    val layoutManager2 = LinearLayoutManager(context)
                    rec_all_product.layoutManager = layoutManager2
                    rec_all_product.itemAnimator = DefaultItemAnimator()
                    rec_all_product.adapter = all_productAdapter
//                }else{
//                    Toast.makeText(context, response.body()!!.message, Toast.LENGTH_LONG).show()
//                }
            }

            override fun onFailure(call: Call<ProductData>, t: Throwable) {
                Log.d("Response::::", t.message.toString())
                progressDialog.dismiss()
            }

        })
    }
}