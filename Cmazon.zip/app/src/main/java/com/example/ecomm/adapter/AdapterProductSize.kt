package com.example.ecomm.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ecomm.R
import com.example.ecomm.activities.Product_Details
import com.example.ecomm.activities.SearchResult
import com.example.ecomm.pojo.Brands
import com.example.ecomm.pojo.ProductColor
import com.example.ecomm.pojo.ProductSize

class AdapterProductSize(private val dataSet: ArrayList<ProductSize>?,
                         private val context: Context?) :
        RecyclerView.Adapter<AdapterProductSize.ViewHolder>() {

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var txt_product_size = view.findViewById<TextView>(R.id.txt_product_size)
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        val view = LayoutInflater.from(context)
                .inflate(R.layout.adapter_product_size, viewGroup, false)

        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val obj= this!!.dataSet!![position];
        viewHolder?.txt_product_size?.text = obj.gettext()

    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = dataSet!!.size

}
